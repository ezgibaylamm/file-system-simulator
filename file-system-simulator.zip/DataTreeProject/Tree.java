package datatreeproject;

public class Tree {

    public Node root;
    public Node current;
    public Node Temp;

    Tree(Node a) {
        this.root = a;
        this.Temp = root;
    }

    public void removenode(Node a,Node delete){
        Node curr = a;
        for(int i = 0;i < curr.subfile.size();i++){
            if(curr.subfile.get(i) == delete){               
                if(curr.subfile.get(i).access){
                    curr.subfile.remove(curr.subfile.get(i));
                    System.out.println("Deleted Successfully");
                    return;
                }
                if(!curr.subfile.get(i).access){
                    System.out.println("Cannot delete SYSTEM files");
                }
                    else{
                    System.out.println("File does not exits");
                }
                curr = curr.subfile.get(i);
                
            }
            removenode(curr.subfile.get(i),delete);
        }
    }

    public boolean addnode(Node a) {
        boolean kosul = false;
        Node curr = this.root;
        for (int i = 0; i < curr.subfile.size(); i++) {
            if (curr.subfile.get(i) == a) {
                curr.subfile.add(a);
                return !kosul;
            } else {
                curr = curr.subfile.get(i);
                return addnode(curr);
            }
        }
        return kosul;

    }

    @Override
    public String toString() {
        return current.toString();
    }
}

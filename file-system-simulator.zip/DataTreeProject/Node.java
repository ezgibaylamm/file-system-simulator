package datatreeproject;

import java.util.ArrayList;
import java.util.Date;

public class Node {

    public int linepoint;
    public int emptycount;
    public String name;
    public String date;
    public boolean access = true;
    public String type;
    public int size;
    public boolean visited = false;
    public ArrayList<Node> subfile = new ArrayList<>();

    Node(String name, int linepoint, int emptycount) {
        if (name.contains("\\")) {
            int index = name.indexOf("\\");
            this.name = name.substring(index + 1);
            this.linepoint = linepoint;
            this.emptycount = emptycount;
            this.type = "Directory";
        }
        if (name.contains("##")) {
            String point = "##";
            String[] sp = name.split(String.valueOf(point), 4);
            int indexofcomma = sp[0].indexOf(".");
            this.name = sp[0].substring(0, indexofcomma);
            this.type = sp[0].substring(indexofcomma + 1);
            if (sp[3].equals("USER")) {
                this.access = true;
            } else if (sp[3].equals("SYSTEM")) {
                this.access = false;
            } else {
                this.access = true;
            }
            this.date = sp[1].toString();
            this.size = Integer.parseInt(sp[2]);
            this.linepoint = linepoint;
            this.emptycount = emptycount;

        }

    }

    Node(String name) {
        this.name = name;
        this.access = true;
        this.type ="Directory";
    }

    Node(String name, String type, int size) {
        this.name = name;
        this.type = type;
        this.size = size;
        Date new_date = new Date();
        this.date = new_date.toString();
    }

    public void addchild(Node a) {
        this.subfile.add(a);
        if (!a.access) {
            this.access = false;
        }

    }

    public void remove(Node b) {
        for (int i = 0; i < this.subfile.size(); i++) {
            if (this.subfile.get(i) == b) {
                if (!access) {
                    System.out.println("System file cannot be deleted!!!!");
                } else {
                    System.out.println("File deleted Successfully!!");
                    this.subfile.remove(i);
                    Date new_date = new Date();
                    this.date = new_date.toString();
                }

            }
        }
    }

    public void modification(String name) {
        this.name = name;
        Date bb = new Date();
        this.name = bb.toString();
    }

    @Override
    public String toString() {
        this.sizecounter();
        if (this.type.equals("Directory")) {
            return "\nname: " + this.name + "\nsize: " + this.size + "\ntype: " + this.type + "\n";
        } else if (!access) {
            return "\nname: " + this.name + "\nsize: " + this.size + "\naccess: " + "SYSTEM" + "\ndate : " + this.date + "\ntype: " + this.type + "\n";
        } else {
            return "\nname: " + this.name + "\nsize: " + this.size + "\naccess: " + "USER" + "\ndate : " + this.date + "\ntype: " + this.type + "\n";
        }

    }

    public String fileToString() {
        String infos = "";
        for (int i = 0; i < this.subfile.size(); i++) {
            infos += this.subfile.get(i).toString();
        }
        return infos;
    }

    public void sizecounter() {
        int a = 0;
        if (this.type.equals("Directory")) {
            for (int i = 0; i < this.subfile.size(); i++) {
                a += this.subfile.get(i).size;
            }
            this.size = a;
        }

    }

    public void acestype() {
        boolean a1 = true;
        if (this.type.equals("Directory")) {
            for (int i = 0; i < this.subfile.size(); i++) {
                if(this.subfile.get(i).access){
                    a1 = false;
                }           
            }
        }else{
            a1 = this.access;
        }
        this.access = a1;
    }

}

package datatreeproject;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class DataTreeProject {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String file = "myfiles.txt"; // Okunacak dosyanın yolu
        Tree tree = new Tree(null);
        int linecounter = 0;
        int[] emptys = new int[77];
        String[] linetxt = new String[77];

        try (Scanner br = new Scanner(new FileReader(file))) {
            String satir = br.nextLine();
            tree = new Tree(new Node(satir.trim(), 0, 0));
            linetxt[linecounter] = "root";
            emptys[linecounter] = 0;
            linecounter++;
            while (br.hasNextLine()) { // Satır satır okuma
                satir = br.nextLine();
                int emptycounter = 0;
                for (int i = 0; i < satir.length(); i++) {
                    if (satir.charAt(i) == '	') {
                        emptycounter++;
                    }
                }
                emptys[linecounter] = emptycounter;
                linetxt[linecounter] = satir.trim();
                linecounter++;
            }

        } catch (IOException e) {
            System.err.println("Dosya okunurken bir hata oluştu: " + e.getMessage());
        }

        TreeNodeadder(tree.root, linecounter, emptys, linetxt);// ADDING NODES TO TREE

        boolean finisher2 = true;
        Node menunode = tree.root;

        while (finisher2) {
            System.out.println("Choose a option:");
            System.out.println("1- Delete a File");
            System.out.println("2- Add a file");
            System.out.println("3- Search and print a file by name");
            System.out.println("4- Print files that containing the entered type");
            System.out.println("5- Make a change on the choosen file");
            System.out.println("6- Display patch");
            System.out.println("7- Exit");
            int given = scanner.nextInt();
            switch (given) {
                case 1:

                    System.out.println("Please enter a file name:");
                    String entered = scanner.next();
                    Node gg = Nodefinder(entered, tree.root);
                    if (gg != null) {
                        if (gg.access) {
                            tree.removenode(tree.root, gg);
                        } else {
                            System.out.println("Cannot delete SYSTEM files");
                        }
                    } else {
                        System.out.println("File does not exists");
                    }

                    break;
                case 2:

                    System.out.println("Enter a parent directory name to add new file: ");
                    String parentdoc = scanner.next();
                    if (Nodefinder(parentdoc, tree.root) != null) {
                        System.out.println("Choose type that you are going to add: ");
                        System.out.println("1- Directory");
                        System.out.println("2- File");
                        int given2 = scanner.nextInt();
                        String g;
                        if (given2 == 1) {
                            System.out.println("Enter a name: ");
                            g = scanner.next();
                            Nodefinder(parentdoc, tree.root).addchild(new Node(g));
                            System.out.println("Added successfully");
                            break;
                        }
                        if (given2 == 2) {
                            System.out.println("Enter a name: ");
                            g = scanner.next();
                            System.out.println("Enter a file type: ");
                            String g2 = scanner.next();
                            System.out.println("Enter a size");
                            int g3 = scanner.nextInt();
                            Nodefinder(parentdoc, tree.root).addchild(new Node(g, g2, g3));
                            System.out.println("Added successfully");

                        } else {
                            System.out.println("Invalid input!!! ");

                        }
                    } else {
                        System.out.println("File or Directory does not exists");
                    }

                    break;
                case 3:
                    System.out.println("Enter a file name to find: ");
                    String g = scanner.next();
                    if (Nodefinder(g, tree.root) != null) {
                        System.out.println("Searched File----------------------------");
                        System.out.println(Nodefinder(g, tree.root).toString());
                        System.out.println("Sub files -------------------------------");
                        System.out.println(Nodefinder(g, tree.root).fileToString());
                    } else {
                        System.out.println("File does not exists");
                    }

                    break;
                case 4:
                    System.out.println("Enter a file type to search: ");
                    String type1 = scanner.next();
                    TypeNodefinder(type1, tree.root);

                    break;
                case 5:
                    System.out.println("Enter a file name to do change");
                    String filename = scanner.next();
                    Node makechange = Nodefinder(filename, tree.root);
                    if (makechange != null) {
                        if (makechange.type.equals("Directory")) {
                            System.out.println("Enter a new name: ");
                            String newname = scanner.next();
                            makechange.name = newname;
                            System.out.println("Name changed!!!");
                        } else {
                            System.out.println("Select a change type: ");
                            System.out.println("1- Change name");
                            System.out.println("2- Resize the byte count");
                            System.out.println("3- Change file type");
                            int chng = scanner.nextInt();

                            switch (chng) {
                                case 1:
                                    System.out.println("Enter a new name: ");
                                    String newname = scanner.next();
                                    makechange.name = newname;
                                    System.out.println("Name changed!!!");

                                    break;
                                case 2:
                                    System.out.println("Enter new size: ");
                                    int newsize = scanner.nextInt();
                                    makechange.size = newsize;
                                    System.out.println("Size changed!!!");
                                    break;
                                case 3:
                                    System.out.println("Enter a new file type: ");
                                    String newtype = scanner.next();
                                    makechange.type = newtype;

                                    break;
                                default:
                                    System.out.println("Invalid input");

                                    break;
                            }
                        }
                    }else{
                        System.out.println("File does not exists");
                    }

                    break;
                case 6:
                    System.out.println("Enter a file name to display patch of: ");
                    String patch = scanner.next();
                    if (!displaypatch(patch, tree.root)) {
                        System.out.println("File does not exists");
                    }
                    break;
                case 7:
                    finisher2 = false;
                default:
                    System.out.println("Invalid input!!!");
                    finisher2 = false;

            }// End of scanner

        }// Main Game runner
    }//End of main

    public static void TreeNodeadder(Node curr, int linecounter, int[] emptys, String[] linetxt) {
        boolean dne = true;
        for (int j = 0; j < linecounter; j++) {
            if (j > curr.linepoint && emptys[j] == ((curr.emptycount) + 1) && dne) {
                Node curnode = new Node(linetxt[j], j, emptys[j]);
                curr.addchild(curnode);
                curr.sizecounter();
                curr.acestype();
                TreeNodeadder(curnode, linecounter, emptys, linetxt);
            }
            if (j > curr.linepoint && emptys[j] <= curr.emptycount) {
                dne = false;
            }
        }
        return;
    }// Recursive method for adding nodes 

    public static void Nodedeleter(String name1, Node a) {
        Node curr = a;
        for (int i = 0; i < curr.subfile.size(); i++) {
            if (curr.subfile.get(i).name.equals(name1)) {
                if (curr.subfile.get(i).access) {
                    System.out.println(curr.subfile.get(i).name + "bulundu");
                    curr.remove(curr.subfile.get(i));
                } else if (!curr.subfile.get(i).access) {
                    System.out.println("Cannot delete SYSTEM file");
                }
            } else {
                Nodedeleter(name1, curr.subfile.get(i));
            }
        }
        System.out.println("Cannot find file ");
    }

    public static Node Nodefinder(String name1, Node a) {
        if (a.name.equals(name1)) {
            return a;
        }
        for (Node i : a.subfile) {
            Node sonuc = Nodefinder(name1, i);
            if (sonuc != null) {
                return sonuc;
            }
        }
        return null;
    }

    public static void TypeNodefinder(String type, Node a) {
        Node curr = a;
        for (int i = 0; i < curr.subfile.size(); i++) {
            if (curr.subfile.get(i).type.equals(type)) {
                System.out.println(curr.subfile.get(i).toString());
            } else {
                TypeNodefinder(type, curr.subfile.get(i));
            }

        }
    }

    public static boolean displaypatch(String name, Node a) {
        String sonuc = "";
        boolean aa = false;
        if (a.name.equals(name)) {
            return true;
        }
        for (Node i : a.subfile) {
            if (displaypatch(name, i)) {
                System.out.println(a);
                return true;
            }
            displaypatch(name, i);
        }
        return aa;
    }
}
